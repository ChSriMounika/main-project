from Crypto.Cipher import DES
from Crypto.Random import get_random_bytes
import secrets

# Generate a random 8-byte (64-bit) secret key
secret_key = secrets.token_bytes(8)
# Replace 'your_secret_key_here' with a 64-bit (8 bytes) secret key
# secret_key = b'your_key'

# Create a DES cipher object
cipher = DES.new(secret_key, DES.MODE_ECB)

# Replace 'input.txt' with the path to your text file
input_file_path = 'input.txt'

# Read the contents of the input file
with open(input_file_path, 'rb') as file:
    plaintext = file.read()

# Pad the plaintext if its length is not a multiple of 8 bytes
if len(plaintext) % 8 != 0:
    plaintext += b'\0' * (8 - len(plaintext) % 8)

# Encrypt the plaintext
encrypted_text = cipher.encrypt(plaintext)

# Replace 'output.txt' with the path where you want to save the encrypted file
output_file_path = 'output.des'

# Write the encrypted data to the output file
with open(output_file_path, 'wb') as file:
    file.write(encrypted_text)

print(f"File '{input_file_path}' encrypted and saved as '{output_file_path}'")


cipher = DES.new(secret_key, DES.MODE_ECB)

# Replace 'output.des' with the path to your encrypted file
encrypted_file_path = 'output.des'

# Read the encrypted data from the file
with open(encrypted_file_path, 'rb') as file:
    encrypted_data = file.read()

# Decrypt the data
decrypted_data = cipher.decrypt(encrypted_data)

# Remove any padding added during encryption
decrypted_data = decrypted_data.rstrip(b'\0')

# Print or use the decrypted data
print("Decrypted Data:")
print(decrypted_data.decode('utf-8'))
