from cryptography.fernet import Fernet
from Crypto.Cipher import DES
import os

from rc4 import rc4_decrypt


# AES Encryption and Decryption
def aes_encrypt(plaintext, key):
    cipher_suite = Fernet(key)
    encrypted_data = cipher_suite.encrypt(plaintext)
    return encrypted_data
def aes_decrypt(ciphertext, key):
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(ciphertext)
    return decrypted_data


# DES Encryption and Decryption
def des_encrypt(plaintext, key):
    cipher = DES.new(key, DES.MODE_ECB)
    plaintext = plaintext + b"\0" * (8 - len(plaintext) % 8)  # Pad the plaintext
    encrypted_data = cipher.encrypt(plaintext)
    return encrypted_data


def des_decrypt(ciphertext, key):
    cipher = DES.new(key, DES.MODE_ECB)
    decrypted_data = cipher.decrypt(ciphertext)
    return decrypted_data.rstrip(b"\0")  # Remove padding


# RC4 Encryption and Decryption
def KSA(key):
    key_length = len(key)
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % key_length]) % 256
        S[i], S[j] = S[j], S[i]
    return S


def PRGA(S, length):
    i = 0
    j = 0
    key = []
    for _ in range(length):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        k = S[(S[i] + S[j]) % 256]
        key.append(k)
    return key


def rc4_encrypt(plaintext, key):
    S = KSA(key)
    keystream = PRGA(S, len(plaintext))
    encrypted = bytes([plaintext[i] ^ keystream[i] for i in range(len(plaintext))])
    return encrypted


# def rc4_decrypt(ciphertext, key):
#     return rc4_encrypt(ciphertext, key)  # RC4 encryption and decryption are the same


# Combined Encryption and Decryption
def combined_encrypt(plaintext, aes_key, des_key, rc4_key):
    # Encrypt with AES
    aes_encrypted = aes_encrypt(plaintext, aes_key)

    # Encrypt with DES
    des_encrypted = des_encrypt(aes_encrypted, des_key)

    # Encrypt with RC4
    rc4_encrypted = rc4_encrypt(des_encrypted, rc4_key)

    return rc4_encrypted





def combined_decrypt(ciphertext, aes_key, des_key, rc4_key):
    # Decrypt with RC4
    rc4_decrypted = rc4_decrypt(ciphertext, rc4_key)

    # Decrypt with DES
    des_decrypted = des_decrypt(rc4_decrypted, des_key)

    # Decrypt with AES
    aes_decrypted = aes_decrypt(des_decrypted, aes_key)

    return aes_decrypted


if __name__ == "__main__":
    # Generate a secure AES key
    aes_key = Fernet.generate_key()

    # Define pre-defined DES and RC4 keys
    des_key = b'YourDesKey'  # 8 bytes
    rc4_key = b'YourRC4Key'  # Variable length

if __name__ == "__main__":
    aes_key = Fernet.generate_key()
    des_key = b'Secret01'  # Example DES key
    rc4_key = b'RandomRC4Key123'  # Example RC4 key

    input_file_path = 'finaltest.txt'

    with open(input_file_path, 'rb') as file:
        plaintext = file.read()

    encrypted_data = combined_encrypt(plaintext, aes_key, des_key, rc4_key)

    # Specify the output file path with a .txt extension
    output_file_path = 'output_combined.txt'

    with open(output_file_path, 'wb') as encrypted_file:
        encrypted_file.write(encrypted_data)

    print(f"File '{input_file_path}' encrypted using combined encryption and saved as '{output_file_path}'")

    decrypted_data = combined_decrypt(encrypted_data, aes_key, des_key, rc4_key)

    decrypted_file_path = 'decrypted_combined.txt'

    with open(decrypted_file_path, 'wb') as decrypted_file:
        decrypted_file.write(decrypted_data)

    print(f"File decrypted and saved as '{decrypted_file_path}'")


    # Replace 'input.txt' with the path to your text file
    input_file_path = 'finaltest.txt'

    with open(input_file_path, 'rb') as file:
        plaintext = file.read()

    encrypted_data = combined_encrypt(plaintext, aes_key, des_key, rc4_key)

    # Specify the output file path
    output_file_path = 'output_combined.bin'

    with open(output_file_path, 'wb') as encrypted_file:
        encrypted_file.write(encrypted_data)

    print(f"File '{input_file_path}' encrypted using combined encryption and saved as '{output_file_path}'")

    # Decrypt the file
    decrypted_data = combined_decrypt(encrypted_data, aes_key, des_key, rc4_key)

    # Specify the decrypted output file path
    decrypted_file_path = 'decrypted_combined.txt'

    with open(decrypted_file_path, 'wb') as decrypted_file:
        decrypted_file.write(decrypted_data)

    print(f"File decrypted and saved as '{decrypted_file_path}'")
