from flask import Flask, render_template, request,session
from cryptography.fernet import Fernet

app = Flask(__name__)

@app.route('/')
def index():
    encrypt_button = 'encryption_key' in session
    decrypt_button = 'encryption_key' in session
    return render_template('index.html', encrypt_button=encrypt_button, decrypt_button=decrypt_button)

@app.route('/upload', methods=['POST'])
def upload():
    # Get the uploaded file from the form
    uploaded_file = request.files['file']

    # Encrypt the uploaded file
    key = Fernet.generate_key()
    cipher_suite = Fernet(key)
    encrypted_data = cipher_suite.encrypt(uploaded_file.read())

    # Save the encrypted data to a file
    encrypted_file_path = 'jitu.encrypted'
    with open(encrypted_file_path, 'wb') as f:
        f.write(encrypted_data)

    return 'File uploaded and encrypted successfully!'

@app.route('/decrypt/<filename>')
def decrypt(filename):
    # Read and decrypt the encrypted file
    key = b'your_generated_key_here'
    cipher_suite = Fernet(key)
    encrypted_file_path = 'encrypted_files/' + filename
    with open(encrypted_file_path, 'rb') as f:
        encrypted_data = f.read()
    decrypted_data = cipher_suite.decrypt(encrypted_data)

    return render_template('decrypt.html', decrypted_content=decrypted_data.decode('utf-8'))


if __name__ == '__main__':
    app.run(debug=True)
