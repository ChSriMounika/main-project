# import flask
from flask import Flask, Response, make_response, render_template, request, send_file
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json
from flask_mail import Mail
from flask import Flask, request, make_response

import os
from flask import Flask, request, make_response, send_file
import os 
from werkzeug.utils import secure_filename

with open("config.json", "r") as c:
    params = json.load(c)["params"]
local_server = "True"
app = Flask(__name__)
app.config['UPLOAD_FOLDER']=params['upload_location']

if (local_server):
    app.config['SQLALCHEMY_DATABASE_URI'] = params["local_uri"]
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = params["prod_uri"]
db = SQLAlchemy(app)




class Files(db.Model):
    __tablename__ = 'files'
    sno = db.Column(db.Integer, primary_key=True, nullable=False)
    email = db.Column(db.String(120))
    filename = db.Column(db.String(255))
    content_type = db.Column(db.String(100))  # Add this column
    file = db.Column(db.LargeBinary)
    hashkey = db.Column(db.String(120))
    date = db.Column(db.String(120), nullable=True)





@app.route("/")
def home():
    return render_template('index.html', params=params)

@app.route("/uploader", methods=['POST'])
def Uploader():
    if request.method == 'POST':
        email = request.form.get('email')
        hashkey = request.form.get('hashkey')
        f = request.files['file1']  # Access the uploaded file

        if f:
            # Read the file data
            file_data = f.read()

            # Get the original filename and content type
            filename = secure_filename(f.filename)
            content_type = f.mimetype

            # Create a new entry in the database
            entry = Files(email=email, filename=filename, content_type=content_type, file=file_data, hashkey=hashkey, date=str(datetime.now()))

            try:
                db.session.add(entry)
                db.session.commit()
                return render_template('uploader.html')

            except Exception as e:
                db.session.rollback()
                print(e)

    return render_template("index.html")



@app.route("/download/<int:sno>", methods=["POST"])
def download_file(sno):
    if request.method == "POST":
        entered_hashkey = request.form.get("entered_hashkey")

        # Query the database to get the file's hashkey
        file_entry = Files.query.get(sno)

        if file_entry:
            file_hashkey = file_entry.hashkey

            # Check if the entered hashkey matches the file's hashkey
            if entered_hashkey == file_hashkey:
                # Save the file to a temporary location on disk
                temp_file_path = os.path.join(app.config["UPLOAD_FOLDER"], file_entry.filename)
                with open(temp_file_path, "wb") as temp_file:
                    temp_file.write(file_entry.file)

                # Serve the saved file
                return send_file(temp_file_path, as_attachment=True, download_name=file_entry.filename)

    return "File download failed. Please check the provided hashkey.", 400



@app.route("/view_files")
def view_files():
    files = Files.query.all()
    return render_template('view_files.html', files=files)

@app.route("/about")
def about():
    return render_template('about.html')


@app.route("/post")
def post():
    return render_template('post.html')


# @app.route("/contact", methods=["GET", "POST"])
# def Uploader():
#     if request.method == "POST":
#         email = request.form.get('email')
#         file = request.form.get('file')
#         hashkey=request.form.get('hashkey')
#         entry = Files(email=email, file=file, date=str(datetime.now()))

#         try:
#             db.session.add(entry)
#             db.session.commit()
#             # mail.send_message("New Message from Blog",
#             #                   sender=email, recipients=[params["GMAIL_USERID"]],
#             #                   body=message + "\n" + phone_num)
#             # If the data is successfully inserted, you can redirect to a success page
#             return 'uploader.html'


#         except Exception as e:
#             db.session.rollback()
#             print(f"Error sending email: {str(e)}")
#     return "uploader.html"

# @app.route("/contact", methods=["GET", "POST"])
# def contact():
#     if request.method == "POST":
#         name = request.form.get('name')
#         email = request.form.get('email')
#         phone_num = request.form.get('phone_num')
#         message = request.form.get('message')
#         entry = Contactus(name=name, email=email, phone_num=phone_num, message=message, date=str(datetime.now()))

#         try:
#             db.session.add(entry)
#             db.session.commit()
#             mail.send_message("New Message from Blog",
#                               sender=email, recipients=[params["GMAIL_USERID"]],
#                               body=message + "\n" + phone_num)
            # If the data is successfully inserted, you can redirect to a success page
            # return render_template('success.html')


    #     except Exception as e:
    #         db.session.rollback()
    #         print(f"Error sending email: {str(e)}")
    # return render_template('contact.html', params=params)


if __name__ == "__main__":
    app.run(debug=True)