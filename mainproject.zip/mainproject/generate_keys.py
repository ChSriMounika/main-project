from cryptography.fernet import Fernet
import os
import base64

# Generate AES, DES, and RC4 keys
aes_key = Fernet.generate_key()
des_key = os.urandom(8)  # 8-byte random DES key
rc4_key = Fernet.generate_key()

# Encode the keys as base64 and save them to a file
with open('keys.txt', 'wb') as key_file:
    key_file.write(f"AES_KEY: {base64.b64encode(aes_key).decode()}\n".encode())
    key_file.write(f"DES_KEY: {base64.b64encode(des_key).decode()}\n".encode())
    key_file.write(f"RC4_KEY: {base64.b64encode(rc4_key).decode()}\n".encode())

print("Keys generated and saved to 'keys.txt'")
