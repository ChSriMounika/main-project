def KSA(key):
    key_length = len(key)
    S = list(range(256))

    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % key_length]) % 256
        S[i], S[j] = S[j], S[i]

    return S


def PRGA(S, length):
    i = 0
    j = 0
    key = []

    for _ in range(length):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        k = S[(S[i] + S[j]) % 256]
        key.append(k)

    return key


def rc4_encrypt(plaintext, key):
    S = KSA(key)
    keystream = PRGA(S, len(plaintext))
    encrypted = bytes([plaintext[i] ^ keystream[i] for i in range(len(plaintext))])
    return encrypted


def rc4_decrypt(ciphertext, key):
    return rc4_encrypt(ciphertext, key)  # RC4 encryption and decryption are the same


def encrypt_file(input_file_path, output_file_path, key):
    with open(input_file_path, 'rb') as file:
        plaintext = file.read()

    encrypted_data = rc4_encrypt(plaintext, key)

    with open(output_file_path, 'wb') as encrypted_file:
        encrypted_file.write(encrypted_data)


def decrypt_file(input_file_path, output_file_path, key):
    with open(input_file_path, 'rb') as encrypted_file:
        ciphertext = encrypted_file.read()

    decrypted_data = rc4_decrypt(ciphertext, key)

    with open(output_file_path, 'wb') as decrypted_file:
        decrypted_file.write(decrypted_data)


if __name__ == "__main__":
    key = b'YourSecretKey'

    input_file_path = 'input.txt'  # Replace with your input file path
    output_encrypted_file_path = 'output_encrypted.txt'
    output_decrypted_file_path = 'output_decrypted.txt'

    # Encrypt the file
    encrypt_file(input_file_path, output_encrypted_file_path, key)
    print(f"File '{input_file_path}' encrypted and saved as '{output_encrypted_file_path}'")

    # Decrypt the file
    decrypt_file(output_encrypted_file_path, output_decrypted_file_path, key)
    print(f"File '{output_encrypted_file_path}' decrypted and saved as '{output_decrypted_file_path}'")
